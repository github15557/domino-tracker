package com.iraq.domino.tracker;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.TextUtils;
import java.util.*;

public class MainActivity extends Activity {
    private final boolean[][] played = new boolean[7][7];
    private final Map<String, TextView> tileViews = new HashMap<>();
    private final ArrayDeque<String> undoStack = new ArrayDeque<>();
    private LinearLayout statsRow, analysisBox, numbersRow;
    private TextView title, subtitle, selectedNumberTitle, remainingText, playedText, warningText, progressText;
    private int selectedNumber = -1;
    private SharedPreferences prefs;

    private final int BG = Color.rgb(17, 24, 39);
    private final int CARD = Color.rgb(31, 41, 55);
    private final int TILE = Color.rgb(248, 250, 252);
    private final int PLAYED = Color.rgb(16, 185, 129);
    private final int ACCENT = Color.rgb(245, 158, 11);
    private final int MUTED = Color.rgb(156, 163, 175);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        prefs = getSharedPreferences("domino_state", MODE_PRIVATE);
        loadState(); buildUi(); refreshAll();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(24));
        root.setBackgroundColor(BG);
        scroll.addView(root);
        setContentView(scroll);

        title = text("متعقّب الدومينو Pro", 28, Color.WHITE, true);
        title.setGravity(Gravity.CENTER); root.addView(title, matchWrap());
        subtitle = text("اختار القطع النازلة، وافحص أي رقم من نفس الواجهة بدون ما تضيع اختياراتك.", 14, MUTED, false);
        subtitle.setGravity(Gravity.CENTER); subtitle.setPadding(0, dp(4), 0, dp(12)); root.addView(subtitle, matchWrap());

        statsRow = new LinearLayout(this); statsRow.setOrientation(LinearLayout.HORIZONTAL); statsRow.setGravity(Gravity.CENTER); root.addView(statsRow, matchWrap());
        progressText = text("", 14, Color.WHITE, true); progressText.setGravity(Gravity.CENTER); progressText.setPadding(0, dp(10), 0, dp(12)); root.addView(progressText, matchWrap());

        TextView gridHeader = text("القطع الـ 28", 18, Color.WHITE, true); gridHeader.setPadding(0, dp(6), 0, dp(8)); root.addView(gridHeader, matchWrap());
        GridLayout grid = new GridLayout(this); grid.setColumnCount(4); grid.setUseDefaultMargins(true); root.addView(grid, matchWrap());
        for (int i=0;i<=6;i++) for (int j=i;j<=6;j++) {
            TextView tv = tileButton(i,j); tileViews.put(key(i,j), tv);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0; lp.height = dp(64); lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            grid.addView(tv, lp);
        }

        TextView checkHeader = text("افحص رقم من نفس الواجهة", 18, Color.WHITE, true); checkHeader.setPadding(0, dp(18), 0, dp(8)); root.addView(checkHeader, matchWrap());
        numbersRow = new LinearLayout(this); numbersRow.setOrientation(LinearLayout.HORIZONTAL); numbersRow.setGravity(Gravity.CENTER); root.addView(numbersRow, matchWrap());
        TextView allBtn = numberButton(-1); LinearLayout.LayoutParams allLp = new LinearLayout.LayoutParams(0, dp(52), 1.2f); allLp.setMargins(dp(3),0,dp(3),0); numbersRow.addView(allBtn, allLp);
        for (int n=0;n<=6;n++) { TextView num = numberButton(n); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1f); lp.setMargins(dp(3),0,dp(3),0); numbersRow.addView(num, lp); }

        analysisBox = new LinearLayout(this); analysisBox.setOrientation(LinearLayout.VERTICAL); analysisBox.setPadding(dp(14),dp(14),dp(14),dp(14)); analysisBox.setBackground(round(CARD, dp(18), 0, 0));
        LinearLayout.LayoutParams ablp = new LinearLayout.LayoutParams(-1, -2); ablp.setMargins(0, dp(12), 0, dp(14)); root.addView(analysisBox, ablp);
        selectedNumberTitle = text("", 18, Color.WHITE, true); remainingText = text("", 15, Color.WHITE, false); playedText = text("", 15, MUTED, false); warningText = text("", 15, ACCENT, true);
        selectedNumberTitle.setPadding(0,0,0,dp(8)); remainingText.setPadding(0,0,0,dp(8)); playedText.setPadding(0,0,0,dp(8));
        analysisBox.addView(selectedNumberTitle); analysisBox.addView(remainingText); analysisBox.addView(playedText); analysisBox.addView(warningText);

        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setGravity(Gravity.CENTER); root.addView(actions, matchWrap());
        actions.addView(actionButton("تراجع", v -> undo()), weightLp()); actions.addView(actionButton("إعادة ضبط", v -> resetGame()), weightLp());
    }

    private TextView tileButton(final int a, final int b) {
        TextView tv = text(a + " | " + b, 20, BG, true); tv.setGravity(Gravity.CENTER); tv.setBackground(round(TILE, dp(16), 0, 0));
        tv.setOnClickListener(v -> { played[a][b] = !played[a][b]; undoStack.push(key(a,b)); saveState(); refreshAll(); }); return tv;
    }
    private TextView numberButton(final int n) {
        TextView tv = text(n == -1 ? "الكل" : String.valueOf(n), n == -1 ? 13 : 18, Color.WHITE, true); tv.setGravity(Gravity.CENTER); tv.setBackground(round(CARD, dp(14), 0, 0));
        tv.setOnClickListener(v -> { selectedNumber = n; refreshAll(); }); return tv;
    }
    private TextView actionButton(String label, View.OnClickListener listener) { TextView tv = text(label, 16, BG, true); tv.setGravity(Gravity.CENTER); tv.setPadding(dp(10),dp(12),dp(10),dp(12)); tv.setBackground(round(ACCENT, dp(16), 0, 0)); tv.setOnClickListener(listener); return tv; }

    private void refreshAll() {
        int playedCount=0; for(int i=0;i<=6;i++) for(int j=i;j<=6;j++) if(played[i][j]) playedCount++;
        statsRow.removeAllViews(); statsRow.addView(statCard("نازلة", String.valueOf(playedCount)), weightLp()); statsRow.addView(statCard("باقية", String.valueOf(28-playedCount)), weightLp()); statsRow.addView(statCard("المجموع", "28"), weightLp());
        progressText.setText("التقدّم: " + playedCount + " / 28");
        for(int i=0;i<=6;i++) for(int j=i;j<=6;j++) { TextView tv = tileViews.get(key(i,j)); if(tv != null) { boolean p=played[i][j]; boolean related = selectedNumber == -1 || i == selectedNumber || j == selectedNumber; boolean remainingRelated = related && !p && selectedNumber != -1; tv.setText(p ? (i+" | "+j+" ✓") : (i+" | "+j)); tv.setTextColor(p ? Color.WHITE : BG); int fill=p?PLAYED:TILE; int stroke=remainingRelated?ACCENT:(p?Color.WHITE:0); int strokeWidth=remainingRelated?dp(3):(p?dp(1):0); tv.setBackground(round(fill, dp(16), stroke, strokeWidth)); tv.setAlpha(related ? (p?0.88f:1f) : 0.38f); }}
        refreshNumberButtons(); refreshAnalysis();
    }
    private void refreshNumberButtons() { for(int child=0; child<numbersRow.getChildCount(); child++) { TextView tv=(TextView)numbersRow.getChildAt(child); int n=child-1; if(n==-1) tv.setText("الكل"); else tv.setText(n + "\n" + remainingForNumber(n).size()); tv.setBackground(round(n == selectedNumber ? ACCENT : CARD, dp(14), 0, 0)); tv.setTextColor(n == selectedNumber ? BG : Color.WHITE); }}
    private void refreshAnalysis() { if(selectedNumber == -1) { selectedNumberTitle.setText("عرض كل القطع"); remainingText.setText("اختار رقم حتى يبرز لك القطع المتبقية منه داخل نفس الشبكة."); playedText.setText("الرقم الصغير تحت كل زر يبين كم قطعة باقية منه."); warningText.setText(""); return; } List<String> rem=remainingForNumber(selectedNumber); List<String> done=playedForNumber(selectedNumber); selectedNumberTitle.setText("رقم " + selectedNumber + " — باقي " + rem.size() + " من 7"); remainingText.setText("ما نازلة: " + (rem.isEmpty()?"ولا قطعة":TextUtils.join("، ", rem))); playedText.setText("نازلة: " + (done.isEmpty()?"ولا قطعة":TextUtils.join("، ", done))); if(rem.isEmpty()) warningText.setText("تنبيه: رقم " + selectedNumber + " خلص بالكامل."); else if(rem.size()==1) warningText.setText("تنبيه: باقي قطعة وحدة فقط على رقم " + selectedNumber + ": " + rem.get(0)); else warningText.setText("القطع المؤشرة بإطار ذهبي هي المتبقية من هذا الرقم."); }

    private List<String> remainingForNumber(int n) { List<String> list=new ArrayList<>(); for(int i=0;i<=6;i++) for(int j=i;j<=6;j++) if((i==n||j==n)&&!played[i][j]) list.add(key(i,j)); return list; }
    private List<String> playedForNumber(int n) { List<String> list=new ArrayList<>(); for(int i=0;i<=6;i++) for(int j=i;j<=6;j++) if((i==n||j==n)&&played[i][j]) list.add(key(i,j)); return list; }
    private View statCard(String label, String value) { LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(dp(8),dp(12),dp(8),dp(12)); box.setBackground(round(CARD, dp(18), 0, 0)); TextView v=text(value,24,Color.WHITE,true); v.setGravity(Gravity.CENTER); TextView l=text(label,13,MUTED,false); l.setGravity(Gravity.CENTER); box.addView(v); box.addView(l); return box; }
    private void undo() { if(undoStack.isEmpty()) { toast("ماكو حركة للتراجع"); return; } int[] p=parse(undoStack.pop()); played[p[0]][p[1]] = !played[p[0]][p[1]]; saveState(); refreshAll(); }
    private void resetGame() { for(int i=0;i<=6;i++) Arrays.fill(played[i], false); undoStack.clear(); saveState(); refreshAll(); toast("تمت إعادة الضبط"); }
    private void saveState() { List<String> items=new ArrayList<>(); for(int i=0;i<=6;i++) for(int j=i;j<=6;j++) if(played[i][j]) items.add(key(i,j)); prefs.edit().putString("played", TextUtils.join(",", items)).apply(); }
    private void loadState() { String saved=getSharedPreferences("domino_state", MODE_PRIVATE).getString("played", ""); if(!saved.isEmpty()) for(String k:saved.split(",")) { int[] p=parse(k.trim()); if(p[0]>=0&&p[1]>=0) played[p[0]][p[1]]=true; } }
    private int[] parse(String k) { try { String[] s=k.split("-"); return new int[]{Integer.parseInt(s[0]), Integer.parseInt(s[1])}; } catch(Exception e) { return new int[]{-1,-1}; } }
    private String key(int a,int b){return a+"-"+b;}
    private TextView text(String s,int sp,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setIncludeFontPadding(true); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private GradientDrawable round(int color,int radius,int strokeColor,int strokeWidth){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); if(strokeWidth>0)g.setStroke(strokeWidth,strokeColor); return g; }
    private LinearLayout.LayoutParams matchWrap(){return new LinearLayout.LayoutParams(-1,-2);} private LinearLayout.LayoutParams weightLp(){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f); lp.setMargins(dp(4),dp(4),dp(4),dp(4)); return lp;} private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
